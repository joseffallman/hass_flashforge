"""Constants for the Flashforge integration."""

DOMAIN = "flashforge"
DEFAULT_NAME = "FlashForge"

CONF_SERIAL_NUMBER = "serial_number"

SCAN_INTERVAL = 30
